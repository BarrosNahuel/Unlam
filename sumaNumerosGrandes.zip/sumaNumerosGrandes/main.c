#include "funciones.h"

int main()
{
    crearArchivosPrueba();
    sumarNumeros("numero1.txt", "numero2.txt", "resultado.txt");
    return 0;
}
